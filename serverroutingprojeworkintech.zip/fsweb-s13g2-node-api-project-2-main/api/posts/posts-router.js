const express = require('express');
const Posts = require('./posts-model');

const router = express.Router();


router.get('/', async (req, res) => {
  try {
    const posts = await Posts.find();
    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Gönderiler alınamadı" });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const post = await Posts.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: "Belirtilen ID'li gönderi bulunamadı" });
    }
    res.json(post);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Gönderi bilgisi alınamadı" });
  }
});


router.post('/', async (req, res) => {
  try {
    const { title, contents } = req.body;
    if (!title || !contents) {
      return res.status(400).json({ message: "Lütfen gönderi için bir title ve contents sağlayın" });
    }
    const inserted = await Posts.insert({ title, contents });
    const newPost = await Posts.findById(inserted.id);
    res.status(201).json(newPost);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Veritabanına kaydedilirken bir hata oluştu" });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const { title, contents } = req.body;
    if (!title || !contents) {
      return res.status(400).json({ message: "Lütfen gönderi için title ve contents sağlayın" });
    }
    const existing = await Posts.findById(req.params.id);
    if (!existing) {
      return res.status(404).json({ message: "Belirtilen ID'li gönderi bulunamadı" });
    }
    const count = await Posts.update(req.params.id, { title, contents });
    if (count) {
      const updated = await Posts.findById(req.params.id);
      return res.json(updated);
    } else {
      return res.status(500).json({ message: "Gönderi bilgileri güncellenemedi" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Gönderi bilgileri güncellenemedi" });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const post = await Posts.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: "Belirtilen ID li gönderi bulunamadı" });
    }
    const count = await Posts.remove(req.params.id);
    if (count) {      
      return res.json(post);
    } else {
      return res.status(500).json({ message: "Gönderi silinemedi" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Gönderi silinemedi" });
  }
});


router.get('/:id/comments', async (req, res) => {
  try {
    const post = await Posts.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: "Girilen ID'li gönderi bulunamadı." });
    }
    const comments = await Posts.findPostComments(req.params.id);
    res.json(comments);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Yorumlar bilgisi getirilemedi" });
  }
});

module.exports = router;
