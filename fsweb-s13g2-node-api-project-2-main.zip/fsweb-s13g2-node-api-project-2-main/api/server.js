// server için gerekli olanları burada ayarlayın

// posts router'ını buraya require edin ve bağlayın
