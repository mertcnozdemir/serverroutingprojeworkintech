const express = require('express');
const cors = require('cors');
const server = express();

server.use(express.json());
server.use(cors());

const postsRouter = require('./posts/posts-router');
server.use('/api/posts', postsRouter);

module.exports = server;
